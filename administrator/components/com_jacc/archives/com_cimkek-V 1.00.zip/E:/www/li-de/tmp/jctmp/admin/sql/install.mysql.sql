CREATE TABLE IF NOT EXISTS `#__cimkek` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cimke` varchar(32) CHARACTER SET utf8 COLLATE utf8_icelandic_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB COLLATE=utf8_hungarian_ci;

